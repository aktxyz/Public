﻿//~=================================================================================================/using

using System.IO;
using System.Xml.Linq;
using System.Xml.Serialization;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{
    public static class TableListData
    {
        public static XDocument GetDoc() { return XDocument.Parse(GetXml()); }

        public static Query GetQuery()
        {
            var xs = (new XmlSerializer(typeof(Query)));
            var sr = new StringReader(GetXml());
            var qq = (Query)xs.Deserialize(sr)!;
            return qq;
        }

        public static string GetXml()
        {
            var xml = Resources.ResourceList.TableListXml;
            return xml;
        }
    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
