﻿//~=================================================================================================/using

using Humanizer;
using Kabamo.Tool;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class TableListXCG : XCG
    {

        //~=========================================================================================/method

        public static List<Record> GetRecordList()
        {
            //var path = @"C:\Programs\Kabamo\Kabamo_Bridge\Kabamo_Bridge_Core_Corelation\SourceData\Query_TableListWithColumnMeta.xml";
            //var xml = path.XFileLoad();
            //var qq = Query.FmXml(xml);
            var qq = TableListData.GetQuery();
            var recordList = qq.GetTransaction0().Step.Where(x => x.Record != null).Select(x => x.Record).ToList();
            return recordList;
        }

        //~=========================================================================================/method

        public static async Task AutoAsync()
        {
            try
            {
                Reset();
                var recordList = GetRecordList();

                //===== using
                WL(@"
//~=================================================================================================/using

using Kabamo.Tool;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
".Trim());
                WL();

                //===== bgn/namespace
                WS("namespace");
                WL("namespace Kabamo.Bridge.Core.Corelation");
                WL("{");

                //===== recordList
                WC("TblNameEnum");
                WL("public enum TblNameEnum");
                WL("{");
                foreach (var record in recordList)
                {
                    var tn = record.TableName.ToLower().Pascalize();
                    WL($"{record.TableName},");
                }
                WL($"NOOP");
                WL("}");

                //===== recordList
                WC("TblName");
                WL("public class TblNameConsts");
                WL("{");
                foreach (var record in recordList)
                {
                    var tn = record.TableName.ToLower().Pascalize();
                    WL($"public const string Tbl{tn} = '{record.TableName}';");
                }
                WL("}");

                //===== recordList
                foreach (var record in recordList)
                {
                    var tn = record.TableName.ToLower().Pascalize();
                    WC(tn);

                    //===== bgn/class
                    WL($"public partial class Tbl{tn}");
                    WL("{");

                    foreach (var field in record.FieldList)
                    {
                        var cn = field.ColumnName.ToLower().Pascalize();
                        var ct = field.DataType.OptionProperty;
                        if (false) { }
                        else if (ct == "E") WL($"public long Col{cn} {{ get; set; }}");
                        else if (ct == "T") WL($"public DateTime Col{cn} {{ get; set; }}");
                        else if (ct == "S") WL($"public string Col{cn} {{ get; set; }} = '';");
                        else if (ct == "O") WL($"public string Col{cn} {{ get; set; }} = '';");
                    }
                    WL();

                    foreach (var field in record.FieldList)
                    {
                        var cn = field.ColumnName.ToLower().Pascalize();
                        var ct = field.DataType.OptionProperty;
                        if (false) { }
                        else if (ct == "E") WL($"public long SetCol{cn}(string ss) {{ Col{cn} = ss.XToLong(); return Col{cn}; }}");
                        else if (ct == "T") WL($"public DateTime SetCol{cn}(string ss) {{ Col{cn} = ss.XToDateTime(); return Col{cn}; }}");
                        else if (ct == "S") WL($"public string SetCol{cn}(string ss) {{ Col{cn} = ss.ToString(); return Col{cn}; }}");
                        else if (ct == "O") WL($"public string SetCol{cn}(string ss) {{ Col{cn} = ss.ToString(); return Col{cn}; }}");
                    }
                    WL("");

                    WL($"public static Tbl{tn} FmRecord(Record record)");
                    WL("{");
                    WL($"var tbl = new Tbl{tn}();");
                    foreach (var field in record.FieldList)
                    {
                        var cn = field.ColumnName.ToLower().Pascalize();
                        var ct = field.DataType.OptionProperty;
                        if (false) { }
                        //else if (ct == "E") WL($"tbl.SetCol{cn}(record.ValueHash['{field.ColumnName}']);");
                        //else if (ct == "T") WL($"tbl.SetCol{cn}(record.ValueHash['{field.ColumnName}']);");
                        //else if (ct == "S") WL($"tbl.SetCol{cn}(record.ValueHash['{field.ColumnName}']);");
                        //else if (ct == "O") WL($"tbl.SetCol{cn}(record.ValueHash['{field.ColumnName}']);");
                        else if (ct == "E") WL($"tbl.Col{cn} = (record.ValueHash['{field.ColumnName}'] ?? '').XToLong();");
                        else if (ct == "T") WL($"tbl.Col{cn} = (record.ValueHash['{field.ColumnName}'] ?? '').XToDateTime();");
                        else if (ct == "S") WL($"tbl.Col{cn} = (record.ValueHash['{field.ColumnName}'] ?? '');");
                        else if (ct == "O") WL($"tbl.Col{cn} = (record.ValueHash['{field.ColumnName}'] ?? '');");
                    }
                    WL($"return tbl;");
                    WL("}");
                    WL("");

                    WL($"public static Step AddRecordView(long serial) {{ return AddRecordView(serial.ToString()); }}");
                    WL($"public static Step AddRecordView(string serial)");
                    WL("{");
                    {
                        WL($"var pp = new Step();");
                        WL($"pp.Record = new Record();");
                        WL($"pp.Record.TableName = '{record.TableName}';");
                        WL($"pp.Record.TargetSerial = serial;");
                        WL($"pp.Record.IncludeAllColumns = Option.New(true);");
                        WL($"pp.Record.IncludeColumnMetadata = Option.New(false);");
                        WL($"pp.Record.IncludeRowDescriptions = Option.New(false);");
                        WL($"pp.Record.IncludeTableMetadata = Option.New(false);");
                        WL($"return pp;");
                    }
                    WL("}");
                    WL("");

                    WL($"public static List<Step> AddRecordView(List<long> serialList) {{ return AddRecordView(serialList.Select(x => x.ToString()).ToList()); }}");
                    WL($"public static List<Step> AddRecordView(List<string> serialList)");
                    WL("{");
                    {
                        WL($"var ppList = new List<Step>();");
                        WL($"foreach (var serial in serialList) ppList.Add(AddRecordView(serial));");
                        WL($"return ppList;");
                    }
                    WL("}");
                    WL("");

                    //===== end/class
                    WL("}");
                }

                //===== end/namespace
                WL("}");
                WS("namespace");

                //===== code
                var code = codeList.XJoinCRLF();
                var file = XGB.PathRoot.XPathAdd("Kabamo_Bridge", "Kabamo_Bridge_Core_Corelation", "SourceAuto", "QueryAuto", "RecordAuto.cs");
                Save(file);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.XTypeMessage());
            }
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
