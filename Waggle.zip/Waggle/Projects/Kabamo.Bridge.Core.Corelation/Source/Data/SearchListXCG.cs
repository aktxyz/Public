﻿//~=================================================================================================/using

using Humanizer;
using Kabamo.Tool;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class SearchListXCG : XCG
    {

        //~=========================================================================================/method

        public static List<Record> GetRecordList()
        {
            //var path = @"C:\Programs\Kabamo\Kabamo_Bridge\Kabamo_Bridge_Core_Corelation\SourceData\Query_TableListWithColumnMeta.xml";
            //var xml = path.XFileLoad();
            //var qq = Query.FmXml(xml);
            var qq = TableListData.GetQuery();
            var recordList = qq.GetTransaction0().Step.Where(x => x.Record != null).Select(x => x.Record).ToList();
            return recordList;
        }

        //~=========================================================================================/method

        public static List<Search> GetSearchList()
        {
            //var path = @"C:\Programs\Kabamo\Kabamo_Bridge\Kabamo_Bridge_Core_Corelation\SourceData\Query_TableListWithColumnMeta.xml";
            //var xml = path.XFileLoad();
            //var qq = Query.FmXml(xml);
            var qq = SearchListData.GetQuery();
            var searchList = qq.GetTransaction0().Step.Where(x => x.Search != null).Select(x => x.Search).ToList();
            return searchList;
        }

        //~=========================================================================================/method

        public static async Task AutoAsync()
        {
            try
            {
                Reset();
                var recordList = GetRecordList();
                var searchList = GetSearchList();

                //===== using
                WL(@"
//~=================================================================================================/using

using Kabamo.Tool;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
".Trim());
                WL();

                //===== bgn/namespace
                WS("namespace");
                WL("namespace Kabamo.Bridge.Core.Corelation");
                WL("{");

                //===== recordList
                foreach (var record in recordList)
                {
                    var tn = record.TableName.ToLower().Pascalize();
                    WC(tn);

                    //===== bgn/class
                    WL($"public partial class Tbl{tn}");
                    WL("{");

                    foreach (var search in searchList.Where(x => x.TableName == record.TableName).ToList())
                    {
                        var sn = search.FilterName.ToLower().Pascalize();
                        var prList = search.Parameter.ToList();

                        if (prList.Count == 0) continue;
                        if (search.FilterName.XIsNone()) continue;
                        if (search.FilterName == "NULL") continue;

                        var mpList = new List<string>();
                        foreach (var pr in prList)
                        {
                            var pt = pr.DataType.OptionProperty;                        // parameter type
                            var pv = pr.ColumnName.ToLower().Camelize();                // parameter variable
                            var cn = pr.ColumnName;
                            var yn = (pr.Options ?? new List<FieldOptions>()).Select(x => x.Value.OptionProperty).OrderBy(x => x).ToList().XJoin() == "NY";
                            if (false) { }
                            else if (pt == "E") mpList.Add($"long {pv}");
                            else if (pt == "T") mpList.Add($"DateTime {pv}");
                            else if (pt == "S") mpList.Add($"string {pv}");
                            else if (pt == "O" && yn) mpList.Add($"bool {pv}");
                            else if (pt == "O") mpList.Add($"string {pv}");
                        }
                        mpList.Add("int returnLimit = 1000");
                        mpList.Add("bool includeTotalHitCount = true");
                        mpList.Add("bool includeSelectColumns = true");
                        mpList.Add("bool includeSelectMetadataWithEachResultRow = true");

                        WL($"public static Step AddSearch_{sn}({mpList.XJoinCMSP()})");
                        WL("{");
                        {
                            WL($"var pp = new Step();");
                            WL($"pp.Search = new Search();");
                            WL($"pp.Search.TableName = '{record.TableName}';");
                            WL($"pp.Search.FilterName = '{search.FilterName}';");
                            WL($"pp.Search.ReturnLimit = returnLimit.ToString();");
                            WL($"pp.Search.IncludeTotalHitCount = Option.YN(includeTotalHitCount);");
                            WL($"pp.Search.IncludeSelectColumns = Option.YN(includeSelectColumns);");
                            WL($"pp.Search.IncludeSelectMetadataWithEachResultRow = Option.YN(includeSelectMetadataWithEachResultRow);");
                            WL($"pp.Search.Parameter ??= new List<Field>();");
                            foreach (var pr in prList)
                            {
                                var pt = pr.DataType.OptionProperty;                    // parameter type
                                var pv = pr.ColumnName.ToLower().Camelize();            // parameter variable
                                var cn = pr.ColumnName;
                                var yn = (pr.Options ?? new List<FieldOptions>()).Select(x => x.Value.OptionProperty).OrderBy(x => x).ToList().XJoin() == "NY";
                                if (false) { }
                                else if (pt == "E") WL($"pp.Search.Parameter.Add(new Field {{ ColumnName = '{cn}', Contents = {pv}.ToString() }});");
                                else if (pt == "T") WL($"pp.Search.Parameter.Add(new Field {{ ColumnName = '{cn}', Contents = {pv}.ToString() }});");
                                else if (pt == "S") WL($"pp.Search.Parameter.Add(new Field {{ ColumnName = '{cn}', Contents = {pv}.ToString() }});");
                                else if (pt == "O" && yn) WL($"pp.Search.Parameter.Add(new Field {{ ColumnName = '{cn}', Contents = {pv}.ToString() }});");
                                else if (pt == "O") WL($"pp.Search.Parameter.Add(new Field {{ ColumnName = '{cn}', Contents = {pv}.ToString() }});");
                            }
                            WL($"return pp;");
                        }
                        WL("}");
                        WL("");
                    }

                    //===== end/class
                    WL("}");
                }

                //===== end/namespace
                WL("}");
                WS("namespace");

                //===== code
                var code = codeList.XJoinCRLF();
                var file = XGB.PathRoot.XPathAdd("Kabamo_Bridge", "Kabamo_Bridge_Core_Corelation", "SourceAuto", "QueryAuto", "SearchAuto.cs");
                Save(file);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.XTypeMessage());
            }
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
