//~=================================================================================================/using

using Kabamo.Tool;
using NS = Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Transaction
    {

        //~=========================================================================================/method

        public Transaction AddPostingRequestTransfer(string loginSerial, string fmSerial, string fmCategorySL, string toSerial, string toCategorySL, string note, decimal amount, string category, string source)
        {
            var tt = this;
            var pp = new NS.Step();

            pp.PostingRequest = new NS.PostingRequest();
            pp.PostingRequest.RegDOption = Option.D();
            pp.PostingRequest.TransferOption = Option.T();
            pp.PostingRequest.Category = Option.New(category);
            pp.PostingRequest.Source = Option.New(source);

            pp.PostingRequest.LoginSerial = loginSerial;
            pp.PostingRequest.Amount = amount.ToString();
            pp.PostingRequest.Description = note;

            pp.PostingRequest.TargetSerial = fmSerial;
            pp.PostingRequest.TargetCategory = Option.New(fmCategorySL);
            pp.PostingRequest.RecipientSerial = toSerial;
            pp.PostingRequest.RecipientCategory = Option.New(toCategorySL);

            tt.Step.Add(pp);
            return tt;
        }

        //~=========================================================================================/method

        public Transaction AddPostingRequestTransfer(string loginSerial, string fmAcctNumber, string toAcctNumber, string note, decimal amount, string category, string source)
        {
            var fmAcct = fmAcctNumber.XSwap("-.*");
            var toAcct = toAcctNumber.XSwap("-.*");

            var fmType = fmAcctNumber.XSwap("[^SL]");
            var toType = toAcctNumber.XSwap("[^SL]");

            var fmId = fmAcctNumber.XSwap(".*(S|L)");
            var toId = toAcctNumber.XSwap(".*(S|L)");

            var tt = this;
            var pp = new NS.Step();

            pp.PostingRequest = new NS.PostingRequest();
            pp.PostingRequest.RegDOption = Option.D();
            pp.PostingRequest.TransferOption = Option.T();
            pp.PostingRequest.Category = Option.New(category);
            pp.PostingRequest.Source = Option.New(source);

            pp.PostingRequest.LoginSerial = loginSerial;
            pp.PostingRequest.Amount = amount.ToString();
            pp.PostingRequest.Description = note;

            pp.PostingRequest.TargetAccountNumber= fmAcct;
            pp.PostingRequest.TargetCategory = Option.New(fmType);
            pp.PostingRequest.TargetId = fmId;
            pp.PostingRequest.RecipientAccountNumber = toAcct;
            pp.PostingRequest.RecipientCategory = Option.New(toType);
            pp.PostingRequest.RecipientId = toId;

            tt.Step.Add(pp);
            return tt;
        }

        //~=========================================================================================/method

        public Transaction AddPostingRequestCheckStop(string loginSerial, string targetSerial, string checkBgn, string checkEnd, decimal checkAmount, string category, string source)
        {
            var tt = this;
            var pp = new NS.Step();

            pp.PostingRequest = new NS.PostingRequest();
            pp.PostingRequest.Category = Option.New(category);
            pp.PostingRequest.Source = Option.New(source);

            pp.PostingRequest.LoginSerial = loginSerial;
            pp.PostingRequest.TargetSerial = targetSerial;
            pp.PostingRequest.DraftNumber = checkBgn;
            if (checkEnd.XIxNone()) pp.PostingRequest.EndingDraftNumber = checkEnd;
            if (checkAmount > 0) pp.PostingRequest.Amount = checkAmount.ToString();

            tt.Step.Add(pp);
            return tt;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
