//~=================================================================================================/using

using NS = Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Transaction
    {

        //~=========================================================================================/method

        public Transaction AddTableList(bool includeTableMetaData = true, bool includeColumnMetaData = false, bool includeAllColumns = false)
        {
            var tt = this;
            var pp = new NS.Step();
            pp.TableList = new NS.TableList();
            pp.TableList.IncludeTableMetadata = Option.New(includeTableMetaData);
            pp.TableList.IncludeColumnMetadata = Option.New(includeColumnMetaData);
            pp.TableList.IncludeAllColumns = Option.New(includeAllColumns);

            tt.Step.Add(pp);
            return tt;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
