//~=================================================================================================/using

using System.Collections.Generic;
using NS = Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Transaction
    {

        //~=========================================================================================/method

        public Transaction AddSearchList(List<Record> recordList)
        {
            var tt = this;
            foreach (var record in recordList)
            {
                var pp = new NS.Step();
                pp.SearchList = new NS.SearchList();
                pp.SearchList.TableName = record.TableName;
                tt.Step.Add(pp);
            }
            return tt;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
