//~=================================================================================================/using

using NS = Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Sequence
    {

        //~=========================================================================================/method

        public Sequence AddPostingStatusByLogin(string loginSerial)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddPostingStatusByLogin(loginSerial);
            return ss;
        }

        //~=========================================================================================/method

        public Sequence AddPostingStatusByAccount(string accountSerial)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddPostingStatusByAccount(accountSerial);
            return ss;
        }

        //~=========================================================================================/method

        public Sequence AddPostingStatusByShare(string shareSerial)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddPostingStatusByShare(shareSerial);
            return ss;
        }

        //~=========================================================================================/method

        public Sequence AddPostingStatusByLoan(string loanSerial)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddPostingStatusByLoan(loanSerial);
            return ss;
        }

        //~=========================================================================================/method

        public Sequence AddPostingStatus(NS.LoginAccessList loginAccessList)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddPostingStatus(loginAccessList, true);
            return ss;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
