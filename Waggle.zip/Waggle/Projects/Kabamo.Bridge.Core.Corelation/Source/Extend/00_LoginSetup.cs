﻿//~=================================================================================================/setup

using System.Xml.Serialization;

namespace Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/class

public partial class LoginSetup
{
    [JsonIgnore][XmlIgnore] public List<Excp> ExceptionList { get { return Exception ?? new List<Excp>(); } }
    [JsonIgnore][XmlIgnore] public bool ExceptionListOk { get { return ExceptionList.Count == 0; } }
    [JsonIgnore][XmlIgnore] public bool HasException { get { return ExceptionList.Count > 0; } }
}

//~=================================================================================================/class
