//~=================================================================================================/using

using Kabamo.Tool;
using System;
using System.Collections.Generic;
using NS = Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Transaction
    {

        //~=========================================================================================/method

        public Transaction AddLoginTranHistory(string loginSerial, string shareSerial, string loanSerial, DateTime dateBgn, DateTime dateEnd, string resumeBookmark, int returnLimit = 200)
        {
            var tt = this;
            var pp = new NS.Step();
            pp.LoginTranHistory = new NS.LoginTranHistory();
            pp.LoginTranHistory.Format = Option.New("S");
            pp.LoginTranHistory.OrderOption = Option.New("RT");
            pp.LoginTranHistory.LoginSerial = loginSerial;
            pp.LoginTranHistory.ShareSerial = shareSerial;
            pp.LoginTranHistory.LoanSerial = loanSerial;
            pp.LoginTranHistory.PostingDateMinimum = dateBgn.XToNice();
            pp.LoginTranHistory.PostingDateMaximum = dateEnd.XToNice();
            pp.LoginTranHistory.ResumeBookmark = resumeBookmark;
            if (returnLimit > 0) pp.LoginTranHistory.ReturnLimit = returnLimit.ToString();
            tt.Step.Add(pp);
            return tt;
        }

        //~=========================================================================================/method

        public Transaction AddLoginTranHistoryByShare(string loginSerial, string shareSerial, DateTime dateBgn, DateTime dateEnd, string resumeBookmark, int returnLimit = 200)
        {
            var tt = this;
            var pp = new NS.Step();
            pp.LoginTranHistory = new NS.LoginTranHistory();
            pp.LoginTranHistory.Format = Option.New("S");
            pp.LoginTranHistory.OrderOption = Option.New("RT");
            pp.LoginTranHistory.LoginSerial = loginSerial;
            pp.LoginTranHistory.ShareSerial = shareSerial;
            pp.LoginTranHistory.PostingDateMinimum = dateBgn.XToNice();
            pp.LoginTranHistory.PostingDateMaximum = dateEnd.XToNice();
            pp.LoginTranHistory.ResumeBookmark = resumeBookmark;
            if (returnLimit > 0) pp.LoginTranHistory.ReturnLimit = returnLimit.ToString();
            tt.Step.Add(pp);
            return tt;
        }

        public Transaction AddLoginTranHistoryByShare(string loginSerial, List<string> shareSerialList, DateTime dateBgn, DateTime dateEnd, List<string> resumeBookmarkList, int returnLimit = 200)
        {
            var tt = this;
            var n = 0;
            foreach (var shareSerial in shareSerialList)
            {
                var resumeBookmark = resumeBookmarkList.XSkipTake1(n) ?? "";
                tt.AddLoginTranHistoryByShare(loginSerial, shareSerial, dateBgn, dateEnd, resumeBookmark);
                n++;
            }
            return tt;
        }

        //~=========================================================================================/method

        public Transaction AddLoginTranHistoryByLoan(string loginSerial, string loanSerial, DateTime dateBgn, DateTime dateEnd, string resumeBookmark, int returnLimit = 200)
        {
            var tt = this;
            var pp = new NS.Step();
            pp.LoginTranHistory = new NS.LoginTranHistory();
            pp.LoginTranHistory.Format = Option.New("S");
            pp.LoginTranHistory.OrderOption = Option.New("RT");
            pp.LoginTranHistory.LoginSerial = loginSerial;
            pp.LoginTranHistory.LoanSerial = loanSerial;
            pp.LoginTranHistory.PostingDateMinimum = dateBgn.XToNice();
            pp.LoginTranHistory.PostingDateMaximum = dateEnd.XToNice();
            pp.LoginTranHistory.ResumeBookmark = resumeBookmark;
            if (returnLimit > 0) pp.LoginTranHistory.ReturnLimit = returnLimit.ToString();
            tt.Step.Add(pp);
            return tt;
        }

        public Transaction AddLoginTranHistoryByLoan(string loginSerial, List<string> loanSerialList, DateTime dateBgn, DateTime dateEnd, List<string> resumeBookmarkList, int returnLimit = 200)
        {
            var tt = this;
            var n = 0;
            foreach (var loanSerial in loanSerialList)
            {
                var resumeBookmark = resumeBookmarkList.XSkipTake1(n) ?? "";
                tt.AddLoginTranHistoryByLoan(loginSerial, loanSerial, dateBgn, dateEnd, resumeBookmark);
                n++;
            }
            return tt;
        }

        //~=========================================================================================/method

        public Transaction AddLoginTranHistoryResume(string loginSerial, NS.Transaction tti)
        {
            var tt = this;
            foreach (var ssi in tti.Step)
            {
                if (ssi.LoginTranHistory != null)
                {
                    var pp = new NS.Step();
                    pp.LoginTranHistory = ssi.LoginTranHistory;
                    ssi.LoginTranHistory.ReturnFormatS?.Transaction?.Clear();
                    ssi.LoginTranHistory.ReturnFormatT?.Transaction?.Clear();
                    ssi.LoginTranHistory.ResumeBookmark = ssi.LoginTranHistory.ResumeBookmarkNext;
                    tt.Step.Add(pp);
                }
            }
            return tt;
        }

        //~=========================================================================================/method

        public Transaction AddLoginTranHistoryByLoginAccessList(string loginSerial, NS.LoginAccessList loginAccessList, DateTime dateBgn, DateTime dateEnd, string resumeBookmark, int returnLimit = 200)
        {
            var tt = this;
            foreach (var subAccount in loginAccessList.SubAccount)
            {
                if (subAccount.TargetCategory.OptionProperty == "S")
                {
                    AddLoginTranHistoryByShare(loginSerial, subAccount.TargetSerial, dateBgn, dateEnd, resumeBookmark, returnLimit);
                }
                if (subAccount.TargetCategory.OptionProperty == "L")
                {
                    AddLoginTranHistoryByLoan(loginSerial, subAccount.TargetSerial, dateBgn, dateEnd, resumeBookmark, returnLimit);
                }
            }
            return tt;
        }

        //~=========================================================================================/method

        public Transaction AddLoginTranHistoryByPostingStatus(string loginSerial, NS.PostingStatus postingStatus, DateTime dateBgn, DateTime dateEnd, string resumeBookmark, int returnLimit = 200)
        {
            var tt = this;
            foreach (var account in postingStatus.Account)
            {
                foreach (var share in account.Share)
                {
                    AddLoginTranHistoryByShare(loginSerial, share.Serial, dateBgn, dateEnd, resumeBookmark, returnLimit);
                }
                foreach (var loan in account.Loan)
                {
                    AddLoginTranHistoryByLoan(loginSerial, loan.Serial, dateBgn, dateEnd, resumeBookmark, returnLimit);
                }
            }
            return tt;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
