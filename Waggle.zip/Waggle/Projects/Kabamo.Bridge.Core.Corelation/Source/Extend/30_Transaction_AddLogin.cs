//~=================================================================================================/using

using Kabamo.Tool;
using NS = Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Transaction
    {

        //~=========================================================================================/method

        public Transaction AddLoginSetup(string accountSerial, string personSerial, string channelSerial, string loginId, string operation)
        {
            var tt = this;
            var pp = new NS.Step();
            pp.LoginSetup = new NS.LoginSetup();
            pp.LoginSetup.AccountSerial = accountSerial;
            pp.LoginSetup.PersonSerial = personSerial;
            pp.LoginSetup.ChannelSerial = channelSerial;
            pp.LoginSetup.LoginId = loginId;
            pp.LoginSetup.Operation = new NS.Option { Value = operation };
            tt.Step.Add(pp);
            return tt;
        }

        //~=========================================================================================/method

        public Transaction AddLoginVerify(string channelSerial, string loginId)
        {
            var tt = this;
            var pp = new NS.Step();
            pp.LoginVerify = new NS.LoginVerify();
            pp.LoginVerify.ChannelSerial = channelSerial;
            pp.LoginVerify.LoginId = loginId;
            tt.Step.Add(pp);
            return tt;
        }

        //~=========================================================================================/method

        public Transaction AddLoginAccessList(string loginSerial, string shareSerial, string loanSerial, bool includePersonRelatedAccounts = true)
        {
            var tt = this;
            var pp = new NS.Step();
            pp.LoginAccessList = new NS.LoginAccessList();
            pp.LoginAccessList.LoginSerial = loginSerial;
            pp.LoginAccessList.ShareSerial = shareSerial;
            pp.LoginAccessList.LoanSerial = loanSerial;
            pp.LoginAccessList.IncludePersonRelatedAccounts = new Option { OptionProperty = includePersonRelatedAccounts.XToYN() };
            pp.LoginAccessList.IncludeDraftLookup = new Option { OptionProperty = "Y" };
            tt.Step.Add(pp);
            return tt;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
