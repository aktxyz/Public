//~=================================================================================================/using

using System.Collections.Generic;

using NS = Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Sequence
    {

        //~=========================================================================================/method

        public Sequence AddLoginTranPending(string loginSerial, string shareSerial, string loanSerial)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddLoginTranPending(loginSerial, shareSerial, loanSerial);
            return ss;
        }

        //~=========================================================================================/method

        public Sequence AddLoginTranPendingByShare(string loginSerial, string shareSerial)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddLoginTranPendingByShare(loginSerial, shareSerial);
            return ss;
        }

        public Sequence AddLoginTranPendingByShare(string loginSerial, List<string> shareSerialList)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddLoginTranPendingByShare(loginSerial, shareSerialList);
            return ss;
        }

        //~=========================================================================================/method

        public Sequence AddLoginTranPendingByLoan(string loginSerial, string loanSerial)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddLoginTranPendingByLoan(loginSerial, loanSerial);
            return ss;
        }

        public Sequence AddLoginTranPendingByLoan(string loginSerial, List<string> loanSerialList)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddLoginTranPendingByLoan(loginSerial, loanSerialList);
            return ss;
        }

        //~=========================================================================================/method

        public Sequence AddLoginTranPending(string loginSerial, NS.LoginAccessList loginAccessList)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddLoginTranPendingByLoginAccessList(loginSerial, loginAccessList);
            return ss;
        }

        //~=========================================================================================/method

        public Sequence AddLoginTranPendingByLoan(string loginSerial, NS.PostingStatus postingStatus)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddLoginTranPendingByPostingStatus(loginSerial, postingStatus);
            return ss;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
