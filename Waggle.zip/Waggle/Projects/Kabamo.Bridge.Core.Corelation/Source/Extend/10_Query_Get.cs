//~=================================================================================================/using

using System.Collections.Generic;
using System.Linq;

using NS = Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Query
    {

        //~=========================================================================================/method

        public NS.Sequence GetSequence0(bool create = true)
        {
            var qq = this;

            //===== sequence
            qq.Sequence ??= new List<NS.Sequence>();
            if (create && qq.Sequence.Count == 0) qq.Sequence.Add(new NS.Sequence());
            var ss = qq.Sequence.FirstOrDefault();
            if (ss == null) return null;

            return ss;
        }

        //~=========================================================================================/method

        public NS.Sequence GetSequenceX(bool create = true)
        {
            var qq = this;

            //===== sequence
            qq.Sequence ??= new List<NS.Sequence>();
            if (create && qq.Sequence.Count == 0) qq.Sequence.Add(new NS.Sequence());
            var ss = qq.Sequence.LastOrDefault();
            if (ss == null) return null;

            return ss;
        }

        //~=========================================================================================/method

        public NS.Transaction GetTransaction0(bool create = true)
        {
            var qq = this;

            //===== sequence
            qq.Sequence ??= new List<NS.Sequence>();
            if (create && qq.Sequence.Count == 0) qq.Sequence.Add(new NS.Sequence());
            var ss = qq.Sequence.FirstOrDefault();
            if (ss == null) return null;

            //===== transaction
            ss.Transaction ??= new List<NS.Transaction>();
            if (create && ss.Transaction.Count == 0) ss.Transaction.Add(new NS.Transaction());
            var tt = ss.Transaction.FirstOrDefault();
            if (tt == null) return null;

            return tt;
        }

        //~=========================================================================================/method

        public NS.Transaction GetTransactionX(bool create = true)
        {
            var qq = this;

            //===== sequence
            qq.Sequence ??= new List<NS.Sequence>();
            if (create && qq.Sequence.Count == 0) qq.Sequence.Add(new NS.Sequence());
            var ss = qq.Sequence.LastOrDefault();
            if (ss == null) return null;

            //===== transaction
            ss.Transaction ??= new List<NS.Transaction>();
            if (create && ss.Transaction.Count == 0) ss.Transaction.Add(new NS.Transaction());
            var tt = ss.Transaction.LastOrDefault();
            if (tt == null) return null;

            return tt;
        }

        //~=========================================================================================/method

        public NS.Step GetStep0(bool create = true)
        {
            var qq = this;

            //===== sequence
            qq.Sequence ??= new List<NS.Sequence>();
            if (create && qq.Sequence.Count == 0) qq.Sequence.Add(new NS.Sequence());
            var ss = qq.Sequence.FirstOrDefault();
            if (ss == null) return null;

            //===== transaction
            ss.Transaction ??= new List<NS.Transaction>();
            if (create && ss.Transaction.Count == 0) ss.Transaction.Add(new NS.Transaction());
            var tt = ss.Transaction.FirstOrDefault();
            if (tt == null) return null;

            //===== step
            tt.Step ??= new List<NS.Step>();
            if (create && tt.Step.Count == 0) tt.Step.Add(new NS.Step());
            var pp = tt.Step.FirstOrDefault();
            if (pp == null) return null;

            return pp;
        }

        //~=========================================================================================/method

        public NS.Step GetStepX(bool create = false)
        {
            var qq = this;

            //===== sequence
            qq.Sequence ??= new List<NS.Sequence>();
            if (create && qq.Sequence.Count == 0) qq.Sequence.Add(new NS.Sequence());
            var ss = qq.Sequence.LastOrDefault();
            if (ss == null) return null;

            //===== transaction
            ss.Transaction ??= new List<NS.Transaction>();
            if (create && ss.Transaction.Count == 0) ss.Transaction.Add(new NS.Transaction());
            var tt = ss.Transaction.LastOrDefault();
            if (tt == null) return null;

            //===== step
            tt.Step ??= new List<NS.Step>();
            if (create && tt.Step.Count == 0) tt.Step.Add(new NS.Step());
            var pp = tt.Step.LastOrDefault();
            if (pp == null) return null;

            return pp;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
