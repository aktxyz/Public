//~=================================================================================================/using

using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Xml.Serialization;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Transaction
    {

        //~=========================================================================================/method

        [XmlIgnore]
        [JsonIgnore]
        public List<Step> StepList { get { return Step ?? new List<Step>(); } }

        //~=========================================================================================/method

        [XmlIgnore]
        [JsonIgnore]
        public List<Excp> ExceptionList { get { return Exception ?? new List<Excp>().ToList(); } }

        [XmlIgnore]
        [JsonIgnore]
        public List<Excp> ExceptionListDeep
        {
            get
            {
                var exceptionList = new List<Excp>();
                exceptionList = exceptionList.Concat(ExceptionList).ToList();
                return exceptionList;
            }
        }

        //~=========================================================================================/method

        //~=========================================================================================/method
    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
