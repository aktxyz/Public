//~=================================================================================================/using

using NS = Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Transaction
    {

        //~=========================================================================================/method

        public Transaction AddPostingStatusByLogin(string loginSerial, bool includeChargedOffAccounts = false, bool includeClosedAccounts = false, bool includeLoginAccessAccounts = true, bool includePersonRelatedAccounts = true)
        {
            var tt = this;
            var pp = new NS.Step();
            pp.PostingStatus = new NS.PostingStatus();
            pp.PostingStatus.TableName = "LOGIN";
            pp.PostingStatus.TargetSerial = loginSerial;
            pp.PostingStatus.IncludeAllNotes = Option.New(true);
            pp.PostingStatus.IncludeChargedOffAccounts = Option.New(includeChargedOffAccounts);
            pp.PostingStatus.IncludeClosedAccounts = Option.New(includeClosedAccounts);
            pp.PostingStatus.IncludeDividendTotals = Option.New(true);
            pp.PostingStatus.IncludeInterestTotals = Option.New(true);
            pp.PostingStatus.IncludeLoginAccessAccounts = Option.New(includeLoginAccessAccounts);
            pp.PostingStatus.IncludePersonRelatedAccounts = Option.New(includePersonRelatedAccounts);

            tt.Step.Add(pp);
            return tt;
        }

        //~=========================================================================================/method
        // TODO: can you pass loginSerial here?

        public Transaction AddPostingStatusByAccount(string accountSerial)
        {
            var tt = this;
            var pp = new NS.Step();
            pp.PostingStatus = new NS.PostingStatus();
            pp.PostingStatus.TableName = "ACCOUNT";
            pp.PostingStatus.TargetSerial = accountSerial;
            pp.PostingStatus.IncludeClosedAccounts = Option.New(true);
            pp.PostingStatus.IncludeDividendTotals = Option.New(true);
            pp.PostingStatus.IncludeInterestTotals = Option.New(true);
            pp.PostingStatus.IncludeLoginAccessAccounts = Option.New(true);
            tt.Step.Add(pp);
            return tt;
        }

        //~=========================================================================================/method
        // TODO add shareDefaults
        // TODO: can you pass loginSerial here?

        public Transaction AddPostingStatusByShare(string shareSerial)
        {
            var tt = this;
            var pp = new NS.Step();
            pp.PostingStatus = new NS.PostingStatus();
            pp.PostingStatus.TableName = "SHARE";
            pp.PostingStatus.TargetSerial = shareSerial;
            pp.PostingStatus.IncludeClosedAccounts = Option.New(true);
            pp.PostingStatus.IncludeDividendTotals = Option.New(true);
            pp.PostingStatus.IncludeInterestTotals = Option.New(true);
            pp.PostingStatus.IncludeLoginAccessAccounts = Option.New(true);
            tt.Step.Add(pp);
            return tt;
        }

        //~=========================================================================================/method
        // TODO add loanDefaults
        // TODO: can you pass loginSerial here?

        public Transaction AddPostingStatusByLoan(string loanSerial)
        {
            var tt = this;
            var pp = new NS.Step();
            pp.PostingStatus = new NS.PostingStatus();
            pp.PostingStatus.TableName = "LOAN";
            pp.PostingStatus.TargetSerial = loanSerial;
            pp.PostingStatus.IncludeClosedAccounts = Option.New(true);
            pp.PostingStatus.IncludeDividendTotals = Option.New(true);
            pp.PostingStatus.IncludeInterestTotals = Option.New(true);
            pp.PostingStatus.IncludeLoginAccessAccounts = Option.New(true);
            tt.Step.Add(pp);
            return tt;
        }

        //~=========================================================================================/method
        // TODO: can you pass loginSerial here?

        public Transaction AddPostingStatus(NS.LoginAccessList loginAccessList, bool skipClosed)
        {
            var tt = this;
            foreach (var subAccount in loginAccessList.SubAccount)
            {
                if (skipClosed && subAccount.Closed != null && subAccount.Closed.IsY()) continue;
                if (subAccount.TargetCategory.OptionProperty == "S")
                {
                    AddPostingStatusByShare(subAccount.TargetSerial);
                }
                if (subAccount.TargetCategory.OptionProperty == "L")
                {
                    AddPostingStatusByLoan(subAccount.TargetSerial);
                }
            }
            return tt;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
