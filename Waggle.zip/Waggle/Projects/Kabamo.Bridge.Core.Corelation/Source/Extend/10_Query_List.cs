//~=================================================================================================/using

using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Xml.Serialization;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Query
    {

        //~=========================================================================================/method

        [XmlIgnore]
        [JsonIgnore]
        public List<Sequence> SequenceList { get { return Sequence ?? new List<Sequence>(); } }

        //~=========================================================================================/method

        [XmlIgnore]
        [JsonIgnore]
        public List<Transaction> TransactionList { get { return SequenceList.SelectMany(x => x.Transaction ?? new List<Transaction>()).ToList(); } }

        //~=========================================================================================/method

        [XmlIgnore]
        [JsonIgnore]
        public List<Step> StepList { get { return TransactionList.SelectMany(x => x.Step ?? new List<Step>()).ToList(); } }

        [XmlIgnore]
        [JsonIgnore]
        public List<Step> StepListPostingStatus { get { return TransactionList.SelectMany(x => x.Step ?? new List<Step>()).Where(x => x.PostingStatus != null).ToList(); } }

        [XmlIgnore]
        [JsonIgnore]
        public List<Step> StepListPostingStatusSh1 { get { return TransactionList.SelectMany(x => x.Step ?? new List<Step>()).Where(x => x.PostingStatus != null && x.PostingStatus.TableName == "SHARE" && x.PostingStatus.ShList.Count == 1).ToList(); } }

        [XmlIgnore]
        [JsonIgnore]
        public List<Step> StepListPostingStatusLn1 { get { return TransactionList.SelectMany(x => x.Step ?? new List<Step>()).Where(x => x.PostingStatus != null && x.PostingStatus.TableName =="LOAN" && x.PostingStatus.ShList.Count == 1).ToList(); } }

        //~=========================================================================================/method

        //[XmlIgnore]
        //[JsonIgnore]
        //public List<Excp> ExceptionList { get { return Exception ?? new List<Excp>().ToList(); } }

        ////~=========================================================================================/method

        //[XmlIgnore]
        //[JsonIgnore]
        //public List<Excp> ExceptionListDeep
        //{
        //    get
        //    {
        //        var exceptionList = new List<Excp>();
        //        exceptionList = exceptionList.Concat(ExceptionList).ToList();
        //        exceptionList = SequenceList.SelectMany(x => x.ExceptionList).ToList();
        //        exceptionList = SequenceList.SelectMany(x => x.TransactionList.SelectMany(y => y.ExceptionList)).ToList();
        //        return exceptionList;
        //    }
        //}

        ////~=========================================================================================/method

        //[XmlIgnore]
        //[JsonIgnore]
        //public bool ExceptionListDeepSNF { get { return ExceptionListDeep.Where(x => x.Reason != null).Any(x => x.Reason.Is("SNF")); } }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
