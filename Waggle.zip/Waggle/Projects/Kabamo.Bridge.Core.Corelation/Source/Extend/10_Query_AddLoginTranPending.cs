//~=================================================================================================/using

using System.Collections.Generic;

using NS = Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Query
    {

        //~=========================================================================================/method

        public Query AddLoginTranPending(string loginSerial, string shareSerial, string loanSerial)
        {
            var qq = this;
            var tt = qq.GetTransaction0();
            tt.AddLoginTranPending(loginSerial, shareSerial, loanSerial);
            return qq;
        }

        //~=========================================================================================/method

        public Query AddLoginTranPendingByShare(string loginSerial, string shareSerial)
        {
            var qq = this;
            var tt = qq.GetTransaction0();
            tt.AddLoginTranPendingByShare(loginSerial, shareSerial);
            return qq;
        }

        public Query AddLoginTranPendingByShare(string loginSerial, List<string> shareSerialList)
        {
            var qq = this;
            var tt = qq.GetTransaction0();
            tt.AddLoginTranPendingByShare(loginSerial, shareSerialList);
            return qq;
        }

        //~=========================================================================================/method

        public Query AddLoginTranPendingByLoan(string loginSerial, string loanSerial)
        {
            var qq = this;
            var tt = qq.GetTransaction0();
            tt.AddLoginTranPendingByLoan(loginSerial, loanSerial);
            return qq;
        }

        public Query AddLoginTranPendingByLoan(string loginSerial, List<string> loanSerialList)
        {
            var qq = this;
            var tt = qq.GetTransaction0();
            tt.AddLoginTranPendingByLoan(loginSerial, loanSerialList);
            return qq;
        }

        //~=========================================================================================/method

        public Query AddLoginTranPending(string loginSerial, NS.LoginAccessList loginAccessList)
        {
            var qq = this;
            var tt = qq.GetTransaction0();
            tt.AddLoginTranPendingByLoginAccessList(loginSerial, loginAccessList);
            return qq;
        }

        //~=========================================================================================/method

        public Query AddLoginTranPending(string loginSerial, NS.PostingStatus postingStatus)
        {
            var qq = this;
            var tt = qq.GetTransaction0();
            tt.AddLoginTranPendingByPostingStatus(loginSerial, postingStatus);
            return qq;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
