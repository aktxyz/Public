//~=================================================================================================/using

using Kabamo.Tool;
using System;
using System.Collections.Generic;
using NS = Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Query
    {

        //~=========================================================================================/method

        public Query AddLoginTranHistory(string loginSerial, string shareSerial, string loanSerial, DateTime dateBgn, DateTime dateEnd, string resumeBookmark = "", int returnLimit = 200)
        {
            var qq = this;
            var tt = qq.GetTransaction0();
            tt.AddLoginTranHistory(loginSerial, shareSerial, loanSerial, dateBgn, dateEnd, resumeBookmark, returnLimit);
            return qq;
        }

        //~=========================================================================================/method

        public Query AddLoginTranHistoryByShSn(string loginSerial, string shareSerial, DateTime dateBgn, DateTime dateEnd, string resumeBookmark = "", int returnLimit = 200)
        {
            var qq = this;
            var tt = qq.GetTransaction0();
            tt.AddLoginTranHistoryByShare(loginSerial, shareSerial, dateBgn, dateEnd, resumeBookmark, returnLimit);
            return qq;
        }

        public Query AddLoginTranHistoryByShare(string loginSerial, List<string> shareSerialList, DateTime dateBgn, DateTime dateEnd, List<string> resumeBookmarkList, int returnLimit = 200)
        {
            var qq = this;
            var nn = 0;
            foreach (var shareSerial in shareSerialList)
            {
                var resumeBookmark = resumeBookmarkList.XSkipTake1(nn) ?? "";
                qq.AddLoginTranHistoryByShSn(loginSerial, shareSerial, dateBgn, dateEnd, resumeBookmark);
                nn++;
            }
            return qq;
        }

        //~=========================================================================================/method

        public Query AddLoginTranHistoryByLnSn(string loginSerial, string loanSerial, DateTime dateBgn, DateTime dateEnd, string resumeBookmark = "", int returnLimit = 200)
        {
            var qq = this;
            var tt = qq.GetTransaction0();
            tt.AddLoginTranHistoryByLoan(loginSerial, loanSerial, dateBgn, dateEnd, resumeBookmark, returnLimit);
            return qq;
        }

        public Query AddLoginTranHistoryByLoan(string loginSerial, List<string> loanSerialList, DateTime dateBgn, DateTime dateEnd, List<string> resumeBookmarkList, int returnLimit = 200)
        {
            var qq = this;
            var nn = 0;
            foreach (var loanSerial in loanSerialList)
            {
                var resumeBookmark = resumeBookmarkList.XSkipTake1(nn) ?? "";
                qq.AddLoginTranHistoryByLnSn(loginSerial, loanSerial, dateBgn, dateEnd, resumeBookmark);
                nn++;
            }
            return qq;
        }

        //~=========================================================================================/method

        public Query AddLoginTranHistory(string loginSerial, NS.LoginTranHistory loginTranHistory)
        {
            var qq = this;
            qq.AddLoginTranHistory(loginSerial, loginTranHistory);
            return qq;
        }

        //~=========================================================================================/method


        public Query AddLoginTranHistory(string loginSerial, NS.LoginAccessList loginAccessList, DateTime dateBgn, DateTime dateEnd, List<string> resumeBookmarkList, int returnLimit = 200)
        {
            var qq = this;
            qq.AddLoginTranHistory(loginSerial, loginAccessList, dateBgn, dateEnd, resumeBookmarkList, returnLimit);
            return qq;
        }

        //~=========================================================================================/method

        public Query AddLoginTranHistory(string loginSerial, NS.PostingStatus postingStatus, DateTime dateBgn, DateTime dateEnd, List<string> resumeBookmarkList, int returnLimit = 200)
        {
            var qq = this;
            qq.AddLoginTranHistory(loginSerial, postingStatus, dateBgn, dateEnd, resumeBookmarkList, returnLimit);
            return qq;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
