//~=================================================================================================/using

using Kabamo.Tool;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Option
    {
        public static Option New(string value)
        {
            var oo = new Option();
            oo.OptionProperty = value;
            return oo;
        }

        public static Option New(bool value)
        {
            var oo = new Option();
            oo.OptionProperty = value.XToYN();
            return oo;
        }

        public static Option YN(bool value)
        {
            var oo = new Option();
            oo.OptionProperty = value.XToYN();
            return oo;
        }

        public static Option A() { var oo = new Option(); oo.OptionProperty = "A"; return oo; }
        public static Option B() { var oo = new Option(); oo.OptionProperty = "B"; return oo; }
        public static Option C() { var oo = new Option(); oo.OptionProperty = "C"; return oo; }
        public static Option D() { var oo = new Option(); oo.OptionProperty = "D"; return oo; }
        public static Option E() { var oo = new Option(); oo.OptionProperty = "E"; return oo; }
        public static Option F() { var oo = new Option(); oo.OptionProperty = "F"; return oo; }
        public static Option G() { var oo = new Option(); oo.OptionProperty = "G"; return oo; }
        public static Option H() { var oo = new Option(); oo.OptionProperty = "H"; return oo; }
        public static Option I() { var oo = new Option(); oo.OptionProperty = "I"; return oo; }
        public static Option J() { var oo = new Option(); oo.OptionProperty = "J"; return oo; }
        public static Option K() { var oo = new Option(); oo.OptionProperty = "K"; return oo; }
        public static Option L() { var oo = new Option(); oo.OptionProperty = "L"; return oo; }
        public static Option M() { var oo = new Option(); oo.OptionProperty = "M"; return oo; }
        public static Option N() { var oo = new Option(); oo.OptionProperty = "N"; return oo; }
        public static Option O() { var oo = new Option(); oo.OptionProperty = "O"; return oo; }
        public static Option P() { var oo = new Option(); oo.OptionProperty = "P"; return oo; }
        public static Option Q() { var oo = new Option(); oo.OptionProperty = "Q"; return oo; }
        public static Option R() { var oo = new Option(); oo.OptionProperty = "R"; return oo; }
        public static Option S() { var oo = new Option(); oo.OptionProperty = "S"; return oo; }
        public static Option T() { var oo = new Option(); oo.OptionProperty = "T"; return oo; }
        public static Option U() { var oo = new Option(); oo.OptionProperty = "U"; return oo; }
        public static Option V() { var oo = new Option(); oo.OptionProperty = "V"; return oo; }
        public static Option W() { var oo = new Option(); oo.OptionProperty = "W"; return oo; }
        public static Option X() { var oo = new Option(); oo.OptionProperty = "X"; return oo; }
        public static Option Y() { var oo = new Option(); oo.OptionProperty = "Y"; return oo; }
        public static Option Z() { var oo = new Option(); oo.OptionProperty = "Z"; return oo; }

        public bool Is(string value)
        {
            if (OptionProperty.ToLower() == value.ToLower()) return true;
            if (Value.ToLower() == value.ToLower()) return true;
            return false;
        }

        public bool IsY()
        {
            if (OptionProperty.ToLower() == "y") return true;
            if (Value.ToLower() == "yes") return true;
            return false;
        }

        public bool IsN()
        {
            if (OptionProperty.ToLower() == "n") return true;
            if (Value.ToLower() == "no") return true;
            return false;
        }
    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
