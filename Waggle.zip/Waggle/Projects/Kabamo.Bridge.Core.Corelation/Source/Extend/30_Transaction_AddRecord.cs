//~=================================================================================================/using

using Kabamo.Tool;
using NS = Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Transaction
    {

        //~=========================================================================================/method

        public Transaction AddRecordView(string tableName, long serial)
        {
            var tt = this;
            var pp = new NS.Step();
            //pp.LoginSetup.PersonSerial = personSerial;
            //pp.LoginSetup.ChannelSerial = channelSerial;
            //pp.LoginSetup.LoginId = loginId;
            //pp.LoginSetup.Operation = new NS.Option { Value = operation };
            tt.Step.Add(pp);
            return tt;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
