//~=================================================================================================/using

using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Xml.Serialization;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Sequence
    {

        //~=========================================================================================/method

        [XmlIgnore]
        [JsonIgnore]
        public List<Transaction> TransactionList { get { return Transaction ?? new List<Transaction>(); } }

        //~=========================================================================================/method

        [XmlIgnore]
        [JsonIgnore]
        public List<Step> StepList { get { return TransactionList.SelectMany(x => x.Step ?? new List<Step>()).ToList(); } }

        //~=========================================================================================/method

        [XmlIgnore]
        [JsonIgnore]
        public List<Excp> ExceptionList { get { return Exception ?? new List<Excp>().ToList(); } }

        //~=========================================================================================/method

        [XmlIgnore]
        [JsonIgnore]
        public List<Excp> ExceptionListDeep
        {
            get
            {
                var exceptionList = new List<Excp>();
                exceptionList = exceptionList.Concat(ExceptionList).ToList();
                exceptionList = TransactionList.SelectMany(x => x.ExceptionList).ToList();
                return exceptionList;
            }
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
