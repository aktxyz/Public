﻿//~=================================================================================================/setup

using System.Xml.Serialization;

namespace Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/class

public partial class PostingStatus
{
    [JsonIgnore][XmlIgnore] public List<Excp> ExceptionList { get { return Exception ?? new List<Excp>(); } }
    [JsonIgnore][XmlIgnore] public bool ExceptionListOk { get { return ExceptionList.Count == 0; } }
    [JsonIgnore][XmlIgnore] public bool HasException { get { return ExceptionList.Count > 0; } }

    [JsonIgnore][XmlIgnore] public List<Account> AcList { get { return Account.ToList(); } }
    [JsonIgnore][XmlIgnore] public List<Share> ShList { get { return Account.SelectMany(x => x.ShList).ToList(); } }
    [JsonIgnore][XmlIgnore] public List<Loan> LnList { get { return Account.SelectMany(x => x.LnList).ToList(); } }

    //~=============================================================================================/method

    public List<string> GetSumm()
    {
        var summ = (new List<string>())
                .Concat(ShList.Select(x => $"PostingStatus/shNm={x.AccountNumberId}/shSn={x.Serial.XToLong():D8}/shTypeSn={x.TypeSerial.XToLong():D8}/{x.Balance:0000000.00}"))
                .Concat(LnList.Select(x => $"PostingStatus/lnNm={x.AccountNumberId}/lnSn={x.Serial.XToLong():D8}/lnTypeSn={x.TypeSerial.XToLong():D8}/{x.Balance:0000000.00}"))
                .ToList();
        return summ;
    }

    //~=============================================================================================/method

}

//~=================================================================================================/class
