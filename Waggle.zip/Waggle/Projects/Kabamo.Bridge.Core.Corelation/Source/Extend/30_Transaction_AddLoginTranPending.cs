//~=================================================================================================/using

using System.Collections.Generic;

using NS = Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Transaction
    {

        //~=========================================================================================/method

        public Transaction AddLoginTranPending(string loginSerial, string shareSerial, string loanSerial)
        {
            var tt = this;
            var pp = new NS.Step();
            pp.LoginTranPending = new NS.LoginTranPending();
            pp.LoginTranPending.LoginSerial = loginSerial;
            pp.LoginTranPending.ShareSerial = shareSerial;
            pp.LoginTranPending.LoanSerial = loanSerial;
            tt.Step.Add(pp);
            return tt;
        }

        //~=========================================================================================/method

        public Transaction AddLoginTranPendingByShare(string loginSerial, string shareSerial)
        {
            var tt = this;
            var pp = new NS.Step();
            pp.LoginTranPending = new NS.LoginTranPending();
            pp.LoginTranPending.LoginSerial = loginSerial;
            pp.LoginTranPending.ShareSerial = shareSerial;
            tt.Step.Add(pp);
            return tt;
        }

        public Transaction AddLoginTranPendingByShare(string loginSerial, List<string> shareSerialList)
        {
            var tt = this;
            var n = 0;
            foreach (var shareSerial in shareSerialList)
            {
                tt.AddLoginTranPendingByShare(loginSerial, shareSerial);
                n++;
            }
            return tt;
        }

        //~=========================================================================================/method

        public Transaction AddLoginTranPendingByLoan(string loginSerial, string loanSerial)
        {
            var tt = this;
            var pp = new NS.Step();
            pp.LoginTranPending = new NS.LoginTranPending();
            pp.LoginTranPending.LoginSerial = loginSerial;
            pp.LoginTranPending.LoanSerial = loanSerial;
            tt.Step.Add(pp);
            return tt;
        }

        public Transaction AddLoginTranPendingByLoan(string loginSerial, List<string> loanSerialList)
        {
            var tt = this;
            var n = 0;
            foreach (var loanSerial in loanSerialList)
            {
                tt.AddLoginTranPendingByLoan(loginSerial, loanSerial);
                n++;
            }
            return tt;
        }

        //~=========================================================================================/method

        public Transaction AddLoginTranPendingByLoginAccessList(string loginSerial, NS.LoginAccessList loginAccessList)
        {
            var tt = this;
            foreach (var subAccount in loginAccessList.SubAccount)
            {
                if (subAccount.TargetCategory.OptionProperty == "S")
                {
                    AddLoginTranPendingByShare(loginSerial, subAccount.TargetSerial);
                }
                if (subAccount.TargetCategory.OptionProperty == "L")
                {
                    AddLoginTranPendingByLoan(loginSerial, subAccount.TargetSerial);
                }
            }
            return tt;
        }

        //~=========================================================================================/method

        public Transaction AddLoginTranPendingByPostingStatus(string loginSerial, NS.PostingStatus postingStatus)
        {
            var tt = this;
            foreach (var account in postingStatus.Account)
            {
                foreach (var share in account.Share)
                {
                    AddLoginTranPendingByShare(loginSerial, share.Serial);
                }
                foreach (var loan in account.Loan)
                {
                    AddLoginTranPendingByLoan(loginSerial, loan.Serial);
                }
            }
            return tt;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
