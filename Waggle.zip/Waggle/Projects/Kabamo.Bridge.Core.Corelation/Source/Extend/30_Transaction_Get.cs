//~=================================================================================================/namespace

using System.Collections.Generic;
using System.Linq;
using Kabamo.Tool;

using NS = Kabamo.Bridge.Core.Corelation;

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Transaction
    {

        //~=========================================================================================/method

        public NS.Step GetStep0(bool create = true)
        {
            var tt = this;

            //===== step
            tt.Step ??= new List<NS.Step>();
            if (create && tt.Step.Count == 0) tt.Step.Add(new NS.Step());
            var pp = tt.Step.FirstOrDefault();
            if (pp == null) return null;

            return pp;
        }

        //~=========================================================================================/method

        public NS.Step GetStepX(bool create = false)
        {
            var tt = this;

            //===== step
            tt.Step ??= new List<NS.Step>();
            if (create && tt.Step.Count == 0) tt.Step.Add(new NS.Step());
            var pp = tt.Step.LastOrDefault();
            if (pp == null) return null;

            return pp;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
