//~=================================================================================================/using

using NS = Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Query
    {

        //~=========================================================================================/method

        public Query AddSessionId(string sessionId)
        {
            var qq = this;
            qq.SessionId = sessionId;
            return qq;
        }

        //~=========================================================================================/method

        public Query AddLogon(string username, string password, string device)
        {
            var qq = this;
            qq.Logon = new NS.Logon();
            qq.Logon.UserName = username;
            qq.Logon.Password = password;
            qq.Logon.DeviceName = device;
            return qq;
        }

        //~=========================================================================================/method

        public Query AddLogoff()
        {
            var qq = this;
            qq.Logoff = new NS.Logoff();
            return qq;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
