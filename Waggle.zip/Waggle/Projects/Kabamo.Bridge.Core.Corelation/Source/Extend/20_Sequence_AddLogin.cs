//~=================================================================================================/using

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Sequence
    {

        //~=========================================================================================/method

        public Sequence AddLoginSetup(string accountSerial, string personSerial, string channelSerial, string loginId, string operation)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddLoginSetup(accountSerial, personSerial, channelSerial, loginId, operation);
            return ss;
        }

        //~=========================================================================================/method

        public Sequence AddLoginVerify(string channelSerial, string loginId)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddLoginVerify(channelSerial, loginId);
            return ss;
        }

        //~=========================================================================================/method

        public Sequence AddLoginAccessList(string loginSerial, string shareSerial, string loanSerial, bool includePersonRelatedAccounts = true)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddLoginAccessList(loginSerial, shareSerial, loanSerial, includePersonRelatedAccounts);
            return ss;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
