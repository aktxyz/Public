//~=================================================================================================/using

using Kabamo.Tool;
using System;
using System.Collections.Generic;
using NS = Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Sequence
    {

        //~=========================================================================================/method

        public Sequence AddLoginTranHistory(string loginSerial, string shareSerial, string loanSerial, DateTime dateBgn, DateTime dateEnd, string resumeBookmark, int returnLimit = 200)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddLoginTranHistory(loginSerial, shareSerial, loanSerial, dateBgn, dateEnd, resumeBookmark, returnLimit);
            return ss;
        }

        //~=========================================================================================/method

        public Sequence AddLoginTranHistoryByShare(string loginSerial, string shareSerial, DateTime dateBgn, DateTime dateEnd, string resumeBookmark, int returnLimit = 200)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddLoginTranHistoryByShare(loginSerial, shareSerial, dateBgn, dateEnd, resumeBookmark, returnLimit);
            return ss;
        }

        public Sequence AddLoginTranHistoryByShare(string loginSerial, List<string> shareSerialList, DateTime dateBgn, DateTime dateEnd, List<string> resumeBookmarkList, int returnLimit = 200)
        {
            var ss = this;
            var nn = 0;
            foreach (var shareSerial in shareSerialList)
            {
                var resumeBookmark = resumeBookmarkList.XSkipTake1(nn) ?? "";
                ss.AddLoginTranHistoryByShare(loginSerial, shareSerial, dateBgn, dateEnd, resumeBookmark);
                nn++;
            }
            return ss;
        }

        //~=========================================================================================/method

        public Sequence AddLoginTranHistoryByLoan(string loginSerial, string loanSerial, DateTime dateBgn, DateTime dateEnd, string resumeBookmark, int returnLimit = 200)
        {
            var ss = this;
            var tt = ss.GetTransaction0();
            tt.AddLoginTranHistoryByLoan(loginSerial, loanSerial, dateBgn, dateEnd, resumeBookmark, returnLimit);
            return ss;
        }

        public Sequence AddLoginTranHistoryByLoan(string loginSerial, List<string> loanSerialList, DateTime dateBgn, DateTime dateEnd, List<string> resumeBookmarkList, int returnLimit = 200)
        {
            var ss = this;
            var nn = 0;
            foreach (var loanSerial in loanSerialList)
            {
                var resumeBookmark = resumeBookmarkList.XSkipTake1(nn) ?? "";
                ss.AddLoginTranHistoryByLoan(loginSerial, loanSerial, dateBgn, dateEnd, resumeBookmark);
                nn++;
            }
            return ss;
        }

        //~=========================================================================================/method

        public Sequence AddLoginTranHistory(string loginSerial, NS.LoginTranHistory loginTranHistory)
        {
            var ss = this;
            ss.AddLoginTranHistory(loginSerial, loginTranHistory);
            return ss;
        }

        //~=========================================================================================/method


        public Sequence AddLoginTranHistory(string loginSerial, NS.LoginAccessList loginAccessList, DateTime dateBgn, DateTime dateEnd, List<string> resumeBookmarkList, int returnLimit = 200)
        {
            var ss = this;
            ss.AddLoginTranHistory(loginSerial, loginAccessList, dateBgn, dateEnd, resumeBookmarkList, returnLimit);
            return ss;
        }

        //~=========================================================================================/method

        public Sequence AddLoginTranHistory(string loginSerial, NS.PostingStatus postingStatus, DateTime dateBgn, DateTime dateEnd, List<string> resumeBookmarkList, int returnLimit = 200)
        {
            var ss = this;
            ss.AddLoginTranHistory(loginSerial, postingStatus, dateBgn, dateEnd, resumeBookmarkList, returnLimit);
            return ss;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
