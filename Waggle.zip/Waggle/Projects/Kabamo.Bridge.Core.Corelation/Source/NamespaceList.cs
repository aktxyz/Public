﻿namespace Kabamo.Module { }
namespace Kabamo.Module.Api { }
namespace Kabamo.Module.App { }
namespace Kabamo.Service { }
namespace Kabamo.Bridge { }
namespace Kabamo.Data { }
namespace Kabamo.Tool { }
namespace Microsoft.EntityFrameworkCore { }