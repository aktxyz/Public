//~=================================================================================================/using

using Kabamo.Tool;
using System;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using NS = Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class DxAcctXrData
    {

        //~=========================================================================================/method

        public Account AC { get; set; }
        public LoginAccessListSubAccount SA { get; set; }
        public Share SH { get; set; }
        public Loan LN { get; set; }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
