//~=================================================================================================/using

using Kabamo.Tool;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Xml.Serialization;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class LoginAccessList
    {
        [JsonIgnore] [XmlIgnore] public bool HasException { get { return Exception == null || Exception.Count == 0; } }

        //~=========================================================================================/method

        public List<string> GetSumm()
        {
            var summ = (new List<string>())
                .Concat(SubAccount.Where(x => x.ShareTypeSerial.XIxNone()).Select(x => $"LoginAccessList/shNm={x.TargetAccountNumber}-S{x.TargetId.XToLong():D4}/shSn={x.TargetSerial.XToLong():D8}/shTypeSn={x.ShareTypeSerial.XToLong():D8}"))
                .Concat(SubAccount.Where(x => x.LoanTypeSerial.XIxNone()).Select(x => $"LoginAccessList/lnNm={x.TargetAccountNumber}-L{x.TargetId.XToLong():D4}/lnSn={x.TargetSerial.XToLong():D8}/lnTypeSn={x.LoanTypeSerial.XToLong():D8}"))
                .ToList();
            return summ;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
