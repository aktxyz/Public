﻿//~=================================================================================================/setup

using System.Xml.Serialization;

namespace Kabamo.Bridge.Core.Corelation;

//~=================================================================================================/class

public partial class LoginTranHistoryReturnFormatS
{

    //~=============================================================================================/method
    
    [XmlIgnore][JsonIgnore] public List<StatementTransaction> TransactionList { get { return Transaction ?? new List<StatementTransaction>().ToList(); } }

    //~=============================================================================================/method

}

//~=================================================================================================/class

public partial class StatementTransaction
{

    //~=================================================================================================/method

    public string MonetarySerial12 { get { return (MonetarySerial ?? "").XPadBgn0(12); } }
    public string XMonetarySerial { get { return (MonetarySerial ?? "").XPadBgn0(12); } }
    public DateTime XPostingDate { get { return PostingDate.XToDateTime().XDdSnap(); } }
    public decimal XPrincipal { get { return Principal.XToDecimal(); } }
    public decimal XNewBalance { get { return NewBalance.XToDecimal(); } }

    //~=================================================================================================/method

}

//~=====================================================================================================/class
