﻿//~=================================================================================================/using

using System.Xml.Serialization;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Loan
    {
        [JsonIgnore][XmlIgnore] public Account Account { get; set; }
        [JsonIgnore][XmlIgnore] public string Serial12 { get { return (Serial ?? "").XPadBgn0(12); } }
        [JsonIgnore][XmlIgnore] public string TypeSerial8 { get { return (TypeSerial ?? "").XPadBgn0(8); } }
        public string AccountNumber { get; set; }
        public string AccountNumberId { get; set; }
        public LoginAccessListSubAccount SubAccount { get; set; }

        //~=========================================================================================/method

        public string GetSumm()
        {
            var ln = this;
            var iq = ln.SubAccount.InquiryAccess.IsY();
            var df = ln.SubAccount.DepositAccess.IsY();
            var wf = ln.SubAccount.WithdrawalAccess.IsY();
            var bl = "{0:00000000##}".XTo(ln.Balance);
            var summ = $"PostingStatus/lnNm={ln.AccountNumberId}/lnSn={ln.Serial.XToLong():D8}/lnTypeSn={ln.TypeSerial.XToLong():D8}/{iq.XToTF()}/{df.XToTF()}/{wf.XToTF()}/{bl}";
            return summ;
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
