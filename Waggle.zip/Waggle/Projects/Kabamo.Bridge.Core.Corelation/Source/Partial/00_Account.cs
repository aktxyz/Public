﻿//~=================================================================================================/using

using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Xml.Serialization;

//~=================================================================================================/namespace

namespace Kabamo.Bridge.Core.Corelation
{

    //~=============================================================================================/class

    public partial class Account
    {
        [JsonIgnore][XmlIgnore] public string Serial12 { get { return (Serial ?? "").XPadBgn0(12); } }

        //~=========================================================================================/method

        [JsonIgnore]
        [XmlIgnore]
        public List<Share> ShList
        {
            get
            {
                foreach (var sh in Share)
                {
                    sh.Account = this;
                    sh.AccountNumber = AccountNumber;
                    sh.AccountNumberId = $"{AccountNumber}-S{sh.Id:D4}";
                }
                return Share.ToList();
            }
        }

        //~=========================================================================================/method

        [JsonIgnore]
        [XmlIgnore]
        public List<Loan> LnList
        {
            get
            {
                foreach (var ln in Loan)
                {
                    ln.Account = this;
                    ln.AccountNumber = AccountNumber;
                    ln.AccountNumberId = $"{AccountNumber}-L{ln.Id:D4}";
                }
                return Loan.ToList();
            }
        }

        //~=========================================================================================/method

    }

    //~=============================================================================================/class

}

//~=================================================================================================/namespace
