---
name: Proposal
about: Create a proposal for Dapr
title: ''
labels: kind/proposal
assignees: ''

---
## Describe the proposal
