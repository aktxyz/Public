---
type: docs
title: "Dapr actors .NET SDK"
linkTitle: "Actors"
weight: 40000
description: Get up and running with the Dapr .NET SDK
---

With the Dapr actor package, you can interact with Dapr virtual actors from a .NET application.

To get started, walk through the [Dapr actors]({{< ref dotnet-actors-howto.md >}}) how-to guide.