// ------------------------------------------------------------------------
// Copyright 2021 The Dapr Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//     http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ------------------------------------------------------------------------

using System.Threading.Tasks;
using Dapr.Actors.Runtime;

namespace Dapr.Actors.AspNetCore.IntegrationTest.App.ActivationTests
{
    public class DependencyInjectionActor : Actor, IDependencyInjectionActor
    {
        private readonly CounterService counter;
        
        public DependencyInjectionActor(ActorHost host, CounterService counter) 
            : base(host)
        {
            this.counter = counter;
        }

        public Task<int> IncrementAsync()
        {
            return Task.FromResult(this.counter.Value++);
        }
    }

    public interface IDependencyInjectionActor : IActor
    {
        Task<int> IncrementAsync();
    }

    public class CounterService
    {
        public int Value { get; set; }
    }
}
